
<?php $user=session()->get('loggedCustomer'); ?>

<?php $__env->startSection('content'); ?>
<?php
$subTotal=0;
?>


<div style="text-align: center;">
    <h3>Your cart</h3>
    <table border="1" align="center" cellpadding="4">
        <tr>
            <th>Medicine name</th>
            <th>Quantity</th>
            <th>Price</th>
        </tr>
        <?php $__currentLoopData = $allCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            <td align="center"><?php echo e($cart->where('cart_id',$cart->cart_id)->first()->Medicines->medicine_name); ?></td>
            <td align="center"><?php echo e($cart->quantity); ?></td>
            <td align="center"><?php echo e(($cart->quantity)*($cart->where('cart_id',$cart->cart_id)->first()->Medicines->price)); ?></td>
            <td><button><a href="<?php echo e(route('cart.remove',['id'=>$cart->cart_id])); ?>">Remove from cart</a></button></td>
        </tr>
        <?php $subTotal +=($cart->quantity)*($cart->where('cart_id',$cart->cart_id)->first()->Medicines->price);?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br>
    <li>Subtotal amount = <b><?php echo e($subTotal); ?></b> TK</li> <br><br><br>
</div>
<?php if($subTotal==0): ?>
<h2 align="center">Your cart is empty. Add medicine first to place order.</h2>
<?php else: ?>
<div style="text-align: center;">
    <h3>Check out ~</h3>
    <form method="post" action="<?php echo e(route('confirm.order')); ?>">
        
            <?php echo e(@csrf_field()); ?>

            
            
            
            <input type="hidden" name="amount" value="<?php echo e($subTotal); ?>">
            Payment method: <select name="method">
                <option value="">Select</option>
                <option value="COD">Cash on delivery</option>
                <option value="MFS">MFS</option>
            </select> <br>
            <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?> <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <br>
            Delivery Address: <input type="text" name="address" placeholder="Provide address"
                value="<?php echo e($user->customer_add); ?>"><br>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?> <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            Contact: <u><?php echo e($user->customer_mob); ?></u><input type="hidden" name="mobile"
                value="<?php echo e($user->customer_mob); ?>"><br>
            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?> <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <input type="submit" value="Place order">
        </form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/customer/cart.blade.php ENDPATH**/ ?>