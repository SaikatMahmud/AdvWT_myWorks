

<?php if(session()->has('loggedCustomer')): ?>
<?php $user=session()->get('loggedCustomer'); ?>    
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<h4><?php echo e(Session::get('regSuccess')); ?></h4>
<h1 align='center'>Customer Homepage <br><br><i>``````Get medicine at your doorstep !``````</i></h1>
<form method="get" action="<?php echo e(route('search.result')); ?>">
<input type="text" name="search" placeholder="Search here" value="">
<input type="submit" value="search">

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make((!session()->has('loggedCustomer') ? 'layouts.beforeLogin' : 'layouts.afterLogin'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/customer/homepage.blade.php ENDPATH**/ ?>