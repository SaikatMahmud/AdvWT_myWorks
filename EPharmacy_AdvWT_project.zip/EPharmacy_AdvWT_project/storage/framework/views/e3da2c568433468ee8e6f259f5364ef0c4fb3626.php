

<?php $__env->startSection('content'); ?>
<h4><?php echo e(Session::get('msg')); ?></h4>
<?php
    $image=Session::get('loggedCustomer')->pro_pic;
   // $image=Session::get('loggedCustomer')->customer_id."_".Session::get('loggedCustomer')->customer_name.".jpg";
   // $imageFull=Storage::extension('public/cus_pic/'.$image);
?>
<p><img src="<?php echo e(asset('storage').'/'.$image); ?>" alt="profile pic" height="90px" width="100px"><br></p>

<form method="post" action="" enctype="multipart/form-data">
    <?php echo e(@csrf_field()); ?>

    Name: <input type="text" name="name" value="<?php echo e($cus->customer_name); ?>"><br>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?> <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    Email: <input type="text" name="email" value="<?php echo e($cus->customer_email); ?>"><br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    Mobile: <input type="text" name="mobile" value="<?php echo e($cus->customer_mob); ?>"><br>
    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    Address: <input type="text" name="address" value="<?php echo e($cus->customer_add); ?>"><br>
    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br>
    Upload profile pic-<input type="file" name='cus_pic'>
    <?php $__errorArgs = ['cus_pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?><br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <br>
        <input type="submit" value="Save">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/customer/profile.blade.php ENDPATH**/ ?>