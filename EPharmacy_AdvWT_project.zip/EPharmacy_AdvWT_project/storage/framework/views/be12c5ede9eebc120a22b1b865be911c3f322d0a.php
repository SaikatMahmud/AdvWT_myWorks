
<?php $__env->startSection('content'); ?>
<br>
<table border="1" cellpadding="4">
    <tr>
        <th>Serial</th>
        <th>Order Number</th>
        <th>Amount</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td align="center"><?php echo e($key+1); ?></td>
        <td align="center"><a href="<?php echo e(route('order.details',['id'=>$order->order_id])); ?>">#<?php echo e($order->order_id); ?></a></td>
        <td align="center"><?php echo e($order->amount); ?></td>
        <td align="center"><?php echo e($order->status); ?></td>
        <td align="center">
            <?php if($order->status=="Canceled"): ?>
            <button>Download</button>

            <?php else: ?>
            <button><a href="<?php echo e(route('order.cancel',['id'=>$order->order_id])); ?>">Cancel</a></button>
            | Download
        </td>
        <?php endif; ?>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><br>
<div align="center"><?php echo e($orders->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/customer/orderList.blade.php ENDPATH**/ ?>