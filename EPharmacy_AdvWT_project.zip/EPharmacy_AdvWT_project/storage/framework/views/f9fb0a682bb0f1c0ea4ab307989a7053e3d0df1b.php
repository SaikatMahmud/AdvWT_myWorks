
<?php if(session()->has('loggedCustomer')): ?>
<?php $user=session()->get('loggedCustomer'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div style="text-align: right;">
    <form method="get" action="<?php echo e(route('search.result')); ?>">
        <input type="text" name="search" placeholder="Search here" value="">
        <input type="submit" value="search">
    </form>
</div>
<?php $__errorArgs = ['stockOut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<?php echo e($message); ?> <br>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table border="1" align="center" cellpadding="10" width="40%">
    <td>
        Name: <?php echo e($med->medicine_name); ?><br>
        Genre: <?php echo e($med->genre); ?><br>
        Brand: <?php echo e($med->Suppliers()->where('medicine_id',$med->medicine_id)->first()->Suppliers->supplier_name); ?>

        &emsp;&emsp;&emsp; 
        Details: <a href="<?php echo e(route('med.details',['id'=>$med->medicine_id])); ?>">see more</a>...<br>
        Price: <?php echo e($med->price); ?> TK
        <div style="text-align: right;">
            <form method="post" action="<?php echo e(route('cus.addtocart')); ?>">
                <?php echo e(@csrf_field()); ?>

                <input type="number" name="quantity<?php echo e($key); ?>" value="<?php echo e(old('quantity'.$key)); ?>" placeholder="Quantity">
                <<?php echo e($med->availability); ?> pc<br>
                    <?php $__errorArgs = ['quantity'.$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?> <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="hidden" name="key" value="<?php echo e($key); ?>">
                    <input type="hidden" name="medId" value="<?php echo e($med->medicine_id); ?>">
                    <input type="hidden" name="avlQuantity" value="<?php echo e($med->availability); ?>">
                    <button>Add to cart</button>&emsp;&emsp;&emsp;&emsp;&emsp;
            </form>
        </div>
        <b><?php echo e(Session::get('added'.$key)); ?></b>
    </td>
</table>
&nbsp;
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>
<div align="center"><?php echo e($results->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make((!session()->has('loggedCustomer') ? 'layouts.beforeLogin' : 'layouts.afterLogin'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/customer/search.blade.php ENDPATH**/ ?>