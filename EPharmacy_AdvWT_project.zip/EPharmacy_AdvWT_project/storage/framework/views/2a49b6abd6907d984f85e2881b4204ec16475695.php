
<?php $user=session()->get('loggedCustomer'); ?>

<?php $__env->startSection('content'); ?>
<h3>Your order has been placed.</h3>
Total amount <b><?php echo e($amount); ?></b>  TK. <br> <br>&emsp; Click here to see your orders.
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.afterLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/customer/order_confirm_msg_page.blade.php ENDPATH**/ ?>