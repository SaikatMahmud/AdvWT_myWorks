<html>
    <head></head>
    <body>
        <div>
            <a href="<?php echo e(route('cus.reg')); ?>">Register</a>
            ||&emsp;
            <a href="<?php echo e(route('user.login')); ?>">Login</a>
            ||&emsp;
            <a href="<?php echo e(route('about')); ?>">About Us</a>
            ||&emsp;
            <a href="<?php echo e(route('contactUs')); ?>">Contact us</a>
        </div>
        <br>
        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/layouts/beforeLogin.blade.php ENDPATH**/ ?>