
<?php $__env->startSection('content'); ?>
<?php if(!Session::has('loggedCustomer')): ?>
<h4><?php echo e(Session::get('msg')); ?></h4>
<form method="post" action="">
    <?php echo e(@csrf_field()); ?>

    Email: <input type="text" name="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>"><br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?> <br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    Password: <input type="password" name="password" ><br>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="submit" value="Login">
    
    <?php $__errorArgs = ['notFound'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo e($message); ?><br>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</form>


    <?php else: ?>
    <h3>You are already logged in</h3>
    <h4>Go to home <a href="<?php echo e(route('home')); ?>">Home</a></h4>

<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make((!session()->has('loggedCustomer') ? 'layouts.beforeLogin' : 'layouts.afterLogin'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/login.blade.php ENDPATH**/ ?>