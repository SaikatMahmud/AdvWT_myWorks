<html>
    <head></head>
    <body>
        <div>
            <a href="<?php echo e(route('home')); ?>">Home</a>
            ||&emsp;
            <a href="<?php echo e(route('about')); ?>">About Us</a>
            ||&emsp;
            <a href="<?php echo e(route('contactUs')); ?>">Contact us</a>

            ||&emsp; &emsp; &emsp; &emsp; 
            
            <a href="<?php echo e(route('cus.profile')); ?>">Edit Profile</a>
            ||&emsp; 
            <a href="<?php echo e(route('cus.cart')); ?>">Cart</a>
            ||&emsp;
            <a href="<?php echo e(route('order.list')); ?>">Orders</a>
            ||&emsp;
            <button type="button"><a href="<?php echo e(route('user.logout')); ?>">Logout</a></button>

            
        </div>
        <br>
        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH C:\Users\USER\Desktop\after problem folder\AdvWT_myWorks\EPharmacy_AdvWT_project\resources\views/layouts/afterLogin.blade.php ENDPATH**/ ?>