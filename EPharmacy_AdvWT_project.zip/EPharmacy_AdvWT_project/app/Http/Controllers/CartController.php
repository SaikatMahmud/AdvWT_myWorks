<?php

namespace App\Http\Controllers;

use App\Models\EPCart;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function addToCart(Request $rq)
    {
        $rq->validate(
            [
                "quantity$rq->key" => "required|integer|max:$rq->avlQuantity",
            ],
            [
                "quantity$rq->key.required" => "The quantity field is required.",
                "quantity$rq->key.integer" => "Must be an decimal number",
                "quantity$rq->key.max" => "More than avaiable stock",
            ]
        );
        $cart = EPCart::where('customer_id', session()->get('loggedCustomer')->customer_id)
            ->where('medicine_id', $rq->medId)->first();
        if ($cart) { 
            EPCart::where('cart_id', $cart->cart_id)->update(
                ['quantity' => $cart->quantity + $rq["quantity$rq->key"]]
            );
            session()->flash("added$rq->key", 'Medicine quantity updated');
            return back();
        }

        $cart = new EPCart();
        $cart->customer_id = session()->get('loggedCustomer')->customer_id;
        $cart->medicine_id = $rq->medId;
        $cart->quantity = $rq["quantity$rq->key"];
        $cart->save();
        if ($cart->save()) {
            session()->flash("added", 'Medicine added to cart');
            return back();
        }
    }
    public function removeFromCart($id){
        EPCart::where('cart_id',$id)->delete();
        return redirect()->route('cus.cart');
    }
}
