@extends('layouts.beforeLogin')
@if (session()->has('loggedCustomer'))
@php $user=session()->get('loggedCustomer'); @endphp    
@endif

@section('content')
<h2 align="center"> This is contact info </h2>
@endsection